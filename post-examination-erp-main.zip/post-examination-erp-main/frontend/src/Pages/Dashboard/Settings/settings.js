/* eslint-disable */ 
import React from 'react';
import { Grid } from '@mui/material';

export default function Settings() {
  return (
    <Grid container spacing={2} />
  );
}
