const express = require('express')


// PUT request to update a course, DELETE request to delete a course, GET request to get course details
// router.route("/product/:id").put(updateCourse).delete(deleteCourse).get(getCourseDetails)

// Entry marks

// Create exam

    

module.exports=router
